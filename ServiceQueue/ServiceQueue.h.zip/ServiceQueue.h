
#ifndef _SERVICE_QUEUE_H
#define _SERVICE_QUEUE_H

#include <iostream>
#include <vector>
#include <utility>



class ServiceQueue {

  private:
        /** Your private data members here! 
        *   (you should have NO PUBLIC data members! 
        *                                            
        * Nested private types also go here.  
        * For example, if your design needs some kind of
        *   structure, you would specify it here.
        */
    //double linked list 
    struct queue{
        int buzzer;
        char inQueue;
        queue *next;
        queue *prev;
        
        queue(int _buzzer = 0, char _inQueue = 'y' , queue* _next = nullptr, queue* _prev = nullptr){
            buzzer= _buzzer;
            inQueue= _inQueue;
            next= _next;
            prev= _prev;
        }
    };
    
    //single linked list
    struct bucket{
        int buzzer;
        bucket *next;
        
        bucket(int _buzzer=0, bucket* _next=nullptr){
            buzzer=_buzzer; next=_next;
        }
    };
    
    //head and back pointers
    queue *queueHd;
    queue *queueBck;
    bucket *bucketHd;
    
    //size of queue and smallest used buzzer
    int queueSize;
    int currSmall;
    
    std::vector<queue*> buzzerAdd;

  public:

	/**
	 * Constructor
	 * Description: intializes an empty service queue.
	 * 
	 * RUNTIME REQUIREMENT: O(1)
	 *
         * TODO
	 */
         ServiceQueue() {
             queueHd = nullptr;
             queueBck = nullptr;
             bucketHd = nullptr;
             queueSize = 0;
             currSmall = 0;
             //buzzerAdd.push_back(new queue());
         }

	/**
	 * Destructor
	 * Description:  deallocates all memory assciated
	 *   with service queue 
	 *
	 * RUNTIME REQUIREMENT:  O(N_b) where N_b is the number of buzzer 
	 *	IDs that have been used during the lifetime of the
	 *	service queue; in general, at any particular instant
	 *	the actual queue length may be less than N_b.
	 *
	 *	[See discussion of "re-using buzzers" below]
	 *
         * TODO
	 */
	~ServiceQueue() {

        }

	/**
	 * Function: snapshot()
         * param:  buzzers is an integer vector passed by ref
	 * Description:  populates buzzers vector with a "snapshot"
         *               of the queue as a sequence of buzzer IDs 
         *
	 *
	 * RUNTIME REQUIREMENT:  O(N)  (where N is the current queue
	 *		length).
	 */
	void snapshot(std::vector<int> &buzzers) {
             buzzers.clear();   // you don't know the history of the 
                                //   buzzers vector, so we had better
                                //   clear it first.
        queue *tmp;
        tmp = queueHd;
        if(queueHd != nullptr){
            while(tmp->next != nullptr){
                buzzers.push_back(tmp->buzzer);
                tmp = tmp->next;
            }
        }
    }

	/**
	 * Function: length()
	 * Description:  returns the current number of
	 *    entries in the queue.
	 *
	 * RUNTIME REQUIREMENT:  O(1)
	 */
	int  length() {
        return queueSize;
        //     return 0;   // placeholder

        }

	/**
	 * Function: give_buzzer()
         * Return:   buzzer-ID (integer) assigned to the new customer.
	 * Description:  This is the "enqueue" operation.  For us
	 *    a "buzzer" is represented by an integer (starting
	 *    from zero).  The function selects an available buzzer 
	 *    and places a new entry at the end of the service queue 
	 *    with the selected buzer-ID. 
	 *    This buzzer ID is returned.
	 *    The assigned buzzer-ID is a non-negative integer 
	 *    with the following properties:
	 *
	 *       (1) the buzzer (really it's ID) is not currently 
	 *         taken -- i.e., not in the queue.  (It
	 *         may have been in the queue at some previous
	 *         time -- i.e., buzzer can be re-used).
	 *	  This makes sense:  you can't give the same
	 *	  buzzer to two people!
	 *
	 *       (2) Reusable Buzzers:  A re-usable buzzer is 
	 *	  a buzzer that _was_ in the queue at some previous
	 *	  time, but currently is not.
	 *
         *         REQUIREMENT:  If there is one or more reusable
         *         buzzer, you MUST return one of them; furthermore,
         *         it must be the buzzer that became reusable most 
         *         MOST RECENTLY.
	 *
	 *       (3) if there are no previously-used / reusable buzzers, 
         *         the SMALLEST possible buzzer-ID is used (retrieved from 
         *         inventory).  
	 *	    Properties in this situation (where N is the current
	 *	      queue length):
	 *
	 *		- The largest buzzer-ID used so far is N-1
	 *
	 *		- All buzzer-IDs in {0..N-1} are in the queue
	 *			(in some order).
	 *
	 *		- The next buzzer-ID (from the basement) is N.
	 *
	 *    In other words, you can always get more buzzers (from
	 *    the basement or something), but you don't fetch an
	 *    additional buzzer unless you have to (i.e., no reusable buzzers).
	 *
	 * Comments/Reminders:
	 *
	 *	Rule (3) implies that when we start from an empty queue,
	 *	the first buzzer-ID will be 0 (zero).
	 *
	 *	Rule (2) does NOT require that the _minimum_ reuseable 
	 *	buzzer-ID be used.  If there are multiple reuseable buzzers, 
	 *	any one of them will do.
	 *	
	 *	Note the following property:  if there are no re-useable 
	 *	buzzers, the queue contains all buzzers in {0..N-1} where
	 *       N is the current queue length (of course, the buzzer IDs 
	 *	may be in any order.)
	 *
	 * RUNTIME REQUIREMENT:  O(1)  ON AVERAGE or "AMORTIZED"  
	 *          In other words, if there have been M calls to 
	 *		give_buzzer, the total time taken for those 
	 *		M calls is O(M).
	 *
	 *		An individual call may therefore not be O(1) so long
	 *		as when taken as a whole they average constant time.
	 *
	 */
	int  give_buzzer() {
        queue * tmpBack;
        bucket * tmpBucket;
        
        //if bucket is not empty
        if(bucketHd != nullptr){
            tmpBack = buzzerAdd[bucketHd->buzzer];      //getting the address from vector
            tmpBack->next = nullptr;                    //setting next to null
            tmpBack->prev = queueBck;                   //setting prev to current back node
            tmpBack->inQueue = 'y';                     //marking that the node is in queue
            queueBck->next = tmpBack;                   //setting last node next to new node
            queueBck = tmpBack;                         //setting back to new node
            tmpBucket = bucketHd;                       //tmp pointer to front of bucket
            
            if(bucketHd->next == nullptr)                //if last node in bucket
            { bucketHd = nullptr;}                       //set buckethd to null
            else
            { bucketHd = bucketHd->next;}                //else move to next node
            
            delete tmpBucket;                            //deleting first node seated person
        }
        
        //if bucket is empty
        else{
            //if queue is empty
            if(queueHd == nullptr){
                tmpBack = new queue(currSmall, 'y',  nullptr, nullptr);     //creeating a new node
                buzzerAdd.push_back(tmpBack);                               //pushing buzzer to end of vector
                queueHd = tmpBack;                                          //updating head of queue
                queueBck = tmpBack;                                         //updating back of queue
                currSmall++;                                                //updating current smallest
            }
            //if the queue is not empty
            else{
                tmpBack = new queue(currSmall, 'y' , nullptr, queueBck);    //creating new node
                buzzerAdd.push_back(tmpBack);                               //pushing address to end of vector
                queueBck->next = tmpBack;                                   //updating current back's next
                queueBck = tmpBack;                                         //updating back of list
                currSmall++;                                                //updating current smalles
            }
        }
 
        queueSize++;              //updating queue size
        return queueBck->buzzer;  // returning buzzer id that was added to end of queue
        }

	/**
	 * function: seat()
	 * description:  if the queue is non-empty, it removes the first 
	 *	 entry from (front of queue) and returns the 
	 *	 buzzer ID.
	 *	 Note that the returned buzzer can now be re-used.
	 *
	 *	 If the queue is empty (nobody to seat), -1 is returned to
	 *	 indicate this fact.
         *
         * Returns:  buzzer ID of dequeued customer, or -1 if queue is empty.
	 *
	 * RUNTIME REQUIREMENT:  O(1)
	 */
	int seat() {
        bucket *tmp;
        queue *queueTmp;
        
        //no buzzer
        if(queueSize <= 0 )
        { return -1; }
        
        //one buzzer
        else if(queueSize ==1){
            //if the bucket is empty
            if(bucketHd == nullptr){
                tmp = new bucket(queueHd->buzzer, nullptr); //creating new node for bucket
                bucketHd = tmp;                             //updating bucket head
            }
            //bucket not empty
            else{
                tmp = new bucket(queueHd->buzzer, bucketHd); //creating new node for bucket
                bucketHd = tmp;                              //updating buckt head
            }
            
            queueHd->inQueue = 'n';                         //updating that node is no longer in queue
            queueHd = nullptr;                              //setiting head to null
            queueBck = nullptr;                             //setting back to null
        }
        
        //2 or more buzzers
        else{
            //creating new node and updating bucket head
            //if bucket is empty
            if(bucketHd == nullptr){
                tmp = new bucket(queueHd->buzzer, nullptr);
                bucketHd = tmp;
            }
            //if bucket it not empty
            else{
                tmp = new bucket(queueHd->buzzer, bucketHd);
                bucketHd = tmp;
            }
            
            queueHd->inQueue = 'n';             //updating that node is no longer in queue
            queueTmp = queueHd;                 //temp pointer to front of list
            queueHd = queueHd->next;            //updating head of queue
            queueTmp->next = nullptr;           //upating next to null
            queueHd->prev = nullptr;            //updating prev to null
        }
        
    
        queueSize --;               //updating queue size
        return bucketHd->buzzer;    //returning buzzer id
        }


	/**
	 * function: kick_out()
	 *
	 * description:  Some times buzzer holders cause trouble and
	 *		a bouncer needs to take back their buzzer and
	 *		tell them to get lost.
	 *
	 *		Specifially:
	 *
	 *		If the buzzer given by the 2nd parameter is 
	 *		in the queue, the buzzer is removed (and the
	 *		buzzer can now be re-used) and 1 (one) is
	 *		returned (indicating success).
	 *
	 * Return:  If the buzzer isn't actually currently in the
	 *		queue, the queue is unchanged and false is returned
	 *		(indicating failure).  Otherwise, true is returned.
	 *
	 * RUNTIME REQUIREMENT:  O(1)
	 */
	bool kick_out(int buzzer) {
        //pointers that will be used
        queue * tmpQueue;
        queue *tmpPrev;
        queue *tmpNext;
        bucket *tmpBucket;
        bucket *bucketNxtPtr;
        
        //checking that buzzer id exist if not return false
        if(buzzer < currSmall)
        { tmpQueue = buzzerAdd[buzzer]; }
        else
        { return false; }
        
        //checking if node is in queue if not return false
        if(tmpQueue->inQueue == 'n'){
            return false;
        }
        
        //chekcing if bucket is empty or not
        //determining what bucket next is going to be
        if(bucketHd == nullptr){
            bucketNxtPtr = nullptr;
        }
        else{
            bucketNxtPtr = bucketHd;
        }
        
        //creating new node for bucket
        tmpBucket = new bucket(queueHd->buzzer, bucketNxtPtr);
        bucketHd = tmpBucket;
        
        //if buzzer beign kicked out is first in line
        if(tmpQueue == queueHd ){
            //updating queue list
            queueHd = queueHd->next;
            queueHd->prev = nullptr;
            tmpQueue->next = nullptr;
        }
        //if buzzer being kicked out is last in line
        else if(tmpQueue == queueBck){
            //updating queue list
            queueBck = queueBck->prev;
            queueBck->next = nullptr;
            tmpQueue->prev = nullptr;
        }
        //else buzzer in middle of list
        else{
            //updating queue list
            tmpPrev = tmpQueue->prev;
            tmpNext = tmpQueue->next;
            tmpPrev->next = tmpNext;
            tmpNext->prev = tmpPrev;
            
            //updating kicked out node
            tmpQueue->next = nullptr;
            tmpQueue->prev = nullptr;
        }
        
        queueSize --; //updating queue size
        return true;  // placeholder

        }

	/**
	 * function:  take_bribe()
	 * description:  some people just don't think the rules of everyday
	 *		life apply to them!  They always want to be at
	 *		the front of the line and don't mind bribing
	 *		a bouncer to get there.
	 *
	 *	        In terms of the function:
	 *
	 *		  - if the given buzzer is in the queue, it is 
	 *		    moved from its current position to the front
	 *		    of the queue.  1 is returned indicating success
	 *		    of the operation.
	 *		  - if the buzzer is not in the queue, the queue 
	 *		    is unchanged and 0 is returned (operation failed).
	 *
	 * Return:  If the buzzer isn't actually currently in the
	 *		queue, the queue is unchanged and false is returned
	 *		(indicating failure).  Otherwise, true is returned.
	 *
	 * RUNTIME REQUIREMENT:  O(1)
	 */
	bool take_bribe(int buzzer) {
        queue *tmp;
        queue *tmpPrev;
        queue *tmpNext;
        
        //checking if buzzer id exist
        if(buzzer < currSmall)
        { tmp = buzzerAdd[buzzer]; }
        else
        { return false; }
        
        //checking if the node is in the queue
        if(tmp->inQueue == 'n'){
            return false;
        }
        
        //if briber is in front of line
        if(tmp == queueHd){
            return true;
        }
        //if briber is in back of line
        else if(tmp == queueBck){
            tmpPrev = tmp->prev;        //temp pointer to previous node
            tmpPrev->next = nullptr;    //setting tempPrev to nullptr
            queueBck = tmpPrev;         //updating back
            tmp->prev = nullptr;        //setting tmep prev to null pointer
            queueHd->prev= tmp;         //setting current head's prev to new front
            queueHd = tmp;              //updating head
        }
        //anywhere else in line
        else{
            tmpPrev = tmp->prev;            //tmp pointer to previous
            tmpNext = tmp->next;            //tmp pointer for next node
            tmpPrev->next = tmpNext;        //pointing pervious to next next node
            tmpNext->prev = tmpPrev;        //pointing next's prev to tmpPrev
            
            tmp->next = queueHd;            //setting the node moved to the front
            tmp->prev = nullptr;            //setting tmp's prev to null
            queueHd->prev = tmp;            //setting currents front to new front
            queueHd = tmp;                  //queue's head is now poiting to new front
        }
    
           return true;  // placeholder

        }



};   // end ServiceQueue class

#endif

